import java.io.Serializable; 
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator; 
import java.util.List;

public class Playlist implements Serializable {
    private static final long serialVersionUID = 1L; 
    private String nome;
    private List<Musica> musicas;
    private transient int indiceMusicaAtual;
    private transient boolean emReproducaoPlaylist; 

    public Playlist(String nome) {
        this.nome = nome;
        this.musicas = new ArrayList<>();
        this.indiceMusicaAtual = -1;
        this.emReproducaoPlaylist = false;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Musica> getMusicas() {
        return musicas;
    }

    public void adicionarMusica(Musica musica) {
        this.musicas.add(musica);
    }

    public void removerMusica(Musica musica) {
        this.musicas.remove(musica);
        if (indiceMusicaAtual >= musicas.size()) {
            indiceMusicaAtual = musicas.isEmpty() ? -1 : musicas.size() - 1;
        }
    }

    public void reordenarMusica(int indiceOriginal, int indiceNovo) {
        if (indiceOriginal >= 0 && indiceOriginal < musicas.size() && indiceNovo >= 0 && indiceNovo < musicas.size()) {
            Collections.swap(musicas, indiceOriginal, indiceNovo);
            if (indiceMusicaAtual == indiceOriginal) {
                indiceMusicaAtual = indiceNovo;
            } else if (indiceMusicaAtual == indiceNovo) {
                indiceMusicaAtual = indiceOriginal;
            }
        }
    }

    public void ordenarMusicas(Comparator<Musica> comparator) {
        if (musicas != null && !musicas.isEmpty()) {
            Collections.sort(this.musicas, comparator);
            System.out.println("Músicas da playlist '" + nome + "' ordenadas.");
        } else {
            System.out.println("A playlist '" + nome + "' está vazia. Nenhuma música para ordenar.");
        }
    }

    public void iniciarReproducao() {
        if (musicas.isEmpty()) {
            System.out.println("A playlist '" + nome + "' está vazia. Não é possível reproduzir.");
            return;
        }
        if (!emReproducaoPlaylist) {
            System.out.println("Iniciando reprodução da playlist: " + nome);
            this.indiceMusicaAtual = 0;
            this.emReproducaoPlaylist = true;
            musicas.get(indiceMusicaAtual).reproduzir();
        } else {
            System.out.println("Playlist '" + nome + "' já está em reprodução.");
        }
    }

    public void pausarReproducao() {
        if (emReproducaoPlaylist && indiceMusicaAtual != -1 && musicas.get(indiceMusicaAtual).estaEmReproducao() && !musicas.get(indiceMusicaAtual).estaPausada()) {
            musicas.get(indiceMusicaAtual).pausar();
        } else {
            System.out.println("Nenhuma música na playlist '" + nome + "' está em reprodução para ser pausada.");
        }
    }

    public void retomarReproducao() {
        if (emReproducaoPlaylist && indiceMusicaAtual != -1 && musicas.get(indiceMusicaAtual).estaPausada()) {
            musicas.get(indiceMusicaAtual).retomar();
        } else if (!emReproducaoPlaylist) {
            System.out.println("Playlist '" + nome + "' não está em reprodução. Use 'Iniciar Reprodução'.");
        } else {
            System.out.println("A música atual da playlist '" + nome + "' não está pausada.");
        }
    }

    public void pararReproducao() {
        if (emReproducaoPlaylist) {
            System.out.println("Parando reprodução da playlist: " + nome);
            if (indiceMusicaAtual != -1) {
                musicas.get(indiceMusicaAtual).parar();
            }
            this.emReproducaoPlaylist = false;
            this.indiceMusicaAtual = -1;
        } else {
            System.out.println("Playlist '" + nome + "' não está em reprodução para ser parada.");
        }
    }

    public void proximaMusica() {
        if (emReproducaoPlaylist && !musicas.isEmpty()) {
            musicas.get(indiceMusicaAtual).parar();
            indiceMusicaAtual++;
            if (indiceMusicaAtual >= musicas.size()) {
                System.out.println("Fim da playlist. Reiniciando do começo.");
                indiceMusicaAtual = 0;
            }
            musicas.get(indiceMusicaAtual).reproduzir();
        } else if (musicas.isEmpty()) {
            System.out.println("A playlist '" + nome + "' está vazia.");
        } else {
            System.out.println("Playlist '" + nome + "' não está em reprodução. Use 'Iniciar Reprodução'.");
        }
    }

    public void musicaAnterior() {
        if (emReproducaoPlaylist && !musicas.isEmpty()) {
            musicas.get(indiceMusicaAtual).parar();
            indiceMusicaAtual--;
            if (indiceMusicaAtual < 0) {
                System.out.println("Início da playlist. Voltando para a última música.");
                indiceMusicaAtual = musicas.size() - 1;
            }
            musicas.get(indiceMusicaAtual).reproduzir();
        } else if (musicas.isEmpty()) {
            System.out.println("A playlist '" + nome + "' está vazia.");
        } else {
            System.out.println("Playlist '" + nome + "' não está em reprodução. Use 'Iniciar Reprodução'.");
        }
    }


    public boolean estaEmReproducaoPlaylist() {
        return emReproducaoPlaylist;
    }

    public Musica getMusicaAtual() {
        if (indiceMusicaAtual != -1 && indiceMusicaAtual < musicas.size()) {
            return musicas.get(indiceMusicaAtual);
        }
        return null;
    }
}