import java.util.Comparator;

public class ComparadorMusicaPorArtista implements Comparator<Musica> {
    @Override
    public int compare(Musica m1, Musica m2) {
        return m1.getArtista().getNome().compareToIgnoreCase(m2.getArtista().getNome());
    }
}