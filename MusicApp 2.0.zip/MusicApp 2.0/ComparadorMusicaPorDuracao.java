import java.util.Comparator;

public class ComparadorMusicaPorDuracao implements Comparator<Musica> {
    @Override
    public int compare(Musica m1, Musica m2) {
        int duracao1Segundos = converterDuracaoParaSegundos(m1.getDuracao());
        int duracao2Segundos = converterDuracaoParaSegundos(m2.getDuracao());

        return Integer.compare(duracao1Segundos, duracao2Segundos);
    }

    private int converterDuracaoParaSegundos(String duracao) {
        String[] partes = duracao.split(":");
        if (partes.length == 2) {
            try {
                int minutos = Integer.parseInt(partes[0]);
                int segundos = Integer.parseInt(partes[1]);
                return minutos * 60 + segundos;
            } catch (NumberFormatException e) {
                System.err.println("Erro ao converter duração: " + duracao + ". Usando 0 segundos.");
                return 0;
            }
        }
        System.err.println("Formato de duração inválido: " + duracao + ". Esperado MM:SS. Usando 0 segundos.");
        return 0;
    }
}