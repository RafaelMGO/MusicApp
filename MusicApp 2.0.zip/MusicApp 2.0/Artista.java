import java.io.Serializable;

public class Artista implements Serializable { 
    private static final long serialVersionUID = 1L;
    private String nome;

    public Artista(String nome) {
        this.nome = nome;
    }

    // Getters e setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}