import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        List<Playlist> playlists = GerenciadorPersistencia.carregarPlaylists();
        List<Musica> musicas = new ArrayList<>();

        for(Playlist p : playlists) {
            for(Musica m : p.getMusicas()) {
                musicas.add(m);
            }
        }

        int opcao;

        do {
            System.out.println("\n--- Sistema de Gerenciamento de Músicas ---");
            System.out.println("1. Cadastrar Música");
            System.out.println("2. Gerenciar Playlist");
            System.out.println("3. Buscar Música");
            System.out.println("4. Reproduzir Música");
            System.out.println("5. Reproduzir Playlist");
            System.out.println("6. Listar Playlists Salvas");
            System.out.println("7. Sair"); 
            System.out.print("Escolha uma opção: ");
            
            try { 
                opcao = entrada.nextInt();
                entrada.nextLine(); 
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, digite um número.");
                entrada.nextLine(); 
                opcao = 0; 
                continue; 
            }

            switch (opcao) {
                case 1:
                    cadastrarMusica(entrada, musicas);
                    break;
                case 2:
                    gerenciarPlaylist(entrada, musicas, playlists);
                    break;
                case 3:
                    buscarMusica(entrada, musicas);
                    break;
                case 4:
                    reproduzirMusica(entrada, musicas);
                    break;
                case 5:
                    reproduzirPlaylist(entrada, playlists);
                    break;
                case 6:
                    listarPlaylistsSalvas(playlists);
                    break;
                case 7:
                    GerenciadorPersistencia.salvarPlaylists(playlists);
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 7);

        entrada.close();
    }

    private static void cadastrarMusica(Scanner entrada, List<Musica> musicas) {
        try {
            System.out.print("Título: ");
            String titulo = entrada.nextLine();
            System.out.print("Nome do Artista: ");
            String nomeArtista = entrada.nextLine();
            Artista artista = new Artista(nomeArtista);
            System.out.print("Nome do Álbum: ");
            String nomeAlbum = entrada.nextLine();
            System.out.print("Ano do Álbum: ");
            int anoAlbum = entrada.nextInt();
            entrada.nextLine();
            Album album = new Album(nomeAlbum, artista, anoAlbum);
            System.out.print("Gênero: ");
            String genero = entrada.nextLine();
            System.out.print("Duração: ");
            String duracao = entrada.nextLine();
            System.out.print("Formato do Arquivo: ");
            String formatoArquivo = entrada.nextLine();
        
            Musica musica = new Musica(titulo, artista, album, genero, duracao, formatoArquivo);
            musicas.add(musica);
            System.out.println("Música cadastrada com sucesso!");
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida para o ano do álbum. Por favor, digite um número inteiro.");
            entrada.nextLine();
        }
    }

    private static void gerenciarPlaylist(Scanner entrada, List<Musica> musicas, List<Playlist> playlists) {
        System.out.println("1. Criar Playlist");
        System.out.println("2. Adicionar Música à Playlist");
        System.out.println("3. Remover Música da Playlist");
        System.out.println("4. Reordenar Música na Playlist");
        System.out.println("5. Ordenar Músicas da Playlist"); 
        System.out.print("Escolha uma opção: ");
        
        try {
            int opcaoPlaylist = entrada.nextInt();
            entrada.nextLine();

            switch (opcaoPlaylist) {
                case 1:
                    System.out.print("Nome da Playlist: ");
                    String nomePlaylist = entrada.nextLine();
                    playlists.add(new Playlist(nomePlaylist));
                    System.out.println("Playlist criada com sucesso!");
                    break;
                case 2:
                    adicionarMusicaPlaylist(entrada, musicas, playlists);
                    break;
                case 3:
                    removerMusicaPlaylist(entrada, playlists);
                    break;
                case 4:
                    reordenarMusicaPlaylist(entrada, playlists);
                    break;
                case 5:
                    ordenarMusicasPlaylist(entrada, playlists);
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
        }
    }

    private static void adicionarMusicaPlaylist(Scanner entrada, List<Musica> musicas, List<Playlist> playlists) {
        if (playlists.isEmpty()) {
            System.out.println("Nenhuma playlist criada.");
            return;
        }

        System.out.println("Playlists disponíveis:");
        for (int i = 0; i < playlists.size(); i++) {
            System.out.println(i + ". " + playlists.get(i).getNome());
        }
        System.out.print("Escolha a playlist: ");
        int escolhaPlaylist = -1;
        try {
            escolhaPlaylist = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaPlaylist < 0 || escolhaPlaylist >= playlists.size()) {
            System.out.println("Playlist inválida.");
            return;
        }

        if (musicas.isEmpty()) {
            System.out.println("Nenhuma música cadastrada.");
            return;
        }

        System.out.println("Músicas disponíveis:");
        for (int i = 0; i < musicas.size(); i++) {
            System.out.println(i + ". " + musicas.get(i).getTitulo() + " - " + musicas.get(i).getArtista().getNome());
        }
        System.out.print("Escolha a música: ");
        int escolhaMusica = -1;
        try {
            escolhaMusica = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaMusica < 0 || escolhaMusica >= musicas.size()) {
            System.out.println("Música inválida.");
            return;
        }

        playlists.get(escolhaPlaylist).adicionarMusica(musicas.get(escolhaMusica));
        System.out.println("Música adicionada à playlist!");
    }

    private static void removerMusicaPlaylist(Scanner entrada, List<Playlist> playlists) {
        if (playlists.isEmpty()) {
            System.out.println("Nenhuma playlist criada.");
            return;
        }

        System.out.println("Playlists disponíveis:");
        for (int i = 0; i < playlists.size(); i++) {
            System.out.println(i + ". " + playlists.get(i).getNome());
        }
        System.out.print("Escolha a playlist: ");
        int escolhaPlaylist = -1;
        try {
            escolhaPlaylist = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaPlaylist < 0 || escolhaPlaylist >= playlists.size()) {
            System.out.println("Playlist inválida.");
            return;
        }

        Playlist playlist = playlists.get(escolhaPlaylist);
        if (playlist.getMusicas().isEmpty()) {
            System.out.println("Playlist vazia.");
            return;
        }

        System.out.println("Músicas na playlist:");
        for (int i = 0; i < playlist.getMusicas().size(); i++) {
            System.out.println(i + ". " + playlist.getMusicas().get(i).getTitulo() + " - " + playlist.getMusicas().get(i).getArtista().getNome());
        }
        System.out.print("Escolha a música para remover: ");
        int escolhaMusica = -1;
        try {
            escolhaMusica = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaMusica < 0 || escolhaMusica >= playlist.getMusicas().size()) {
            System.out.println("Música inválida.");
            return;
        }

        playlist.removerMusica(playlist.getMusicas().get(escolhaMusica));
        System.out.println("Música removida da playlist!");
    }

    private static void reordenarMusicaPlaylist(Scanner entrada, List<Playlist> playlists) {
        if (playlists.isEmpty()) {
            System.out.println("Nenhuma playlist criada.");
            return;
        }

        System.out.println("Playlists disponíveis:");
        for (int i = 0; i < playlists.size(); i++) {
            System.out.println(i + ". " + playlists.get(i).getNome());
        }
        System.out.print("Escolha a playlist: ");
        int escolhaPlaylist = -1;
        try {
            escolhaPlaylist = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaPlaylist < 0 || escolhaPlaylist >= playlists.size()) {
            System.out.println("Playlist inválida.");
            return;
        }

        Playlist playlist = playlists.get(escolhaPlaylist);
        if (playlist.getMusicas().isEmpty()) {
            System.out.println("Playlist vazia.");
            return;
        }

        System.out.println("Músicas na playlist:");
        for (int i = 0; i < playlist.getMusicas().size(); i++) {
            System.out.println(i + ". " + playlist.getMusicas().get(i).getTitulo() + " - " + playlist.getMusicas().get(i).getArtista().getNome());
        }
        System.out.print("Índice da música a reordenar: ");
        int indiceOriginal = -1;
        try {
            indiceOriginal = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }
        System.out.print("Novo índice da música: ");
        int indiceNovo = -1;
        try {
            indiceNovo = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (indiceOriginal < 0 || indiceOriginal >= playlist.getMusicas().size() ||
                indiceNovo < 0 || indiceNovo >= playlist.getMusicas().size()) {
            System.out.println("Índice inválido.");
            return;
        }

        playlist.reordenarMusica(indiceOriginal, indiceNovo);
        System.out.println("Música reordenada na playlist!");
    }

    private static void ordenarMusicasPlaylist(Scanner entrada, List<Playlist> playlists) {
        if (playlists.isEmpty()) {
            System.out.println("Nenhuma playlist criada para ordenar.");
            return;
        }

        System.out.println("Playlists disponíveis:");
        for (int i = 0; i < playlists.size(); i++) {
            System.out.println(i + ". " + playlists.get(i).getNome());
        }
        System.out.print("Escolha a playlist para ordenar: ");
        int escolhaPlaylist = -1;
        try {
            escolhaPlaylist = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaPlaylist < 0 || escolhaPlaylist >= playlists.size()) {
            System.out.println("Playlist inválida.");
            return;
        }

        Playlist playlist = playlists.get(escolhaPlaylist);

        if (playlist.getMusicas().isEmpty()) {
            System.out.println("A playlist '" + playlist.getNome() + "' está vazia. Nenhuma música para ordenar.");
            return;
        }

        System.out.println("\nCritérios de Ordenação:");
        System.out.println("1. Título (crescente)");
        System.out.println("2. Artista (crescente)");
        System.out.println("3. Duração (crescente)");
        System.out.print("Escolha o critério de ordenação: ");
        int criterioOrdenacao = -1;
        try {
            criterioOrdenacao = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        Comparator<Musica> comparator = null;
        switch (criterioOrdenacao) {
            case 1:
                comparator = new Comparator<Musica>() { 
                    @Override
                    public int compare(Musica m1, Musica m2) {
                        return m1.getTitulo().compareToIgnoreCase(m2.getTitulo());
                    }
                };
                break;
            case 2:
                comparator = new ComparadorMusicaPorArtista(); 
                break;
            case 3:
                comparator = new ComparadorMusicaPorDuracao(); 
                break;
            default:
                System.out.println("Critério de ordenação inválido.");
                return;
        }
        playlist.ordenarMusicas(comparator);
        System.out.println("Playlist '" + playlist.getNome() + "' ordenada com sucesso!");
    }

    private static void buscarMusica(Scanner entrada, List<Musica> musicas) {
        System.out.println("Buscar música por:");
        System.out.println("1. Título");
        System.out.println("2. Artista");
        System.out.println("3. Álbum");
        System.out.println("4. Gênero");
        System.out.println("5. Ano de Lançamento");
        System.out.print("Escolha o critério de busca: ");
        int criterio = -1;
        try {
            criterio = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }
        System.out.print("Digite o termo de busca: ");
        String termo = entrada.nextLine();
    
        List<Musica> resultados = new ArrayList<>();
        for (Musica musica : musicas) {
            switch (criterio) {
                case 1:
                    if (musica.getTitulo().toLowerCase().contains(termo.toLowerCase())) {
                        resultados.add(musica);
                    }
                    break;
                case 2:
                    if (musica.getArtista().getNome().toLowerCase().contains(termo.toLowerCase())) {
                        resultados.add(musica);
                    }
                    break;
                case 3:
                    if (musica.getAlbum().getNome().toLowerCase().contains(termo.toLowerCase())) {
                        resultados.add(musica);
                    }
                    break;
                case 4:
                    if (musica.getGenero().toLowerCase().contains(termo.toLowerCase())) {
                        resultados.add(musica);
                    }
                    break;
                case 5:
                    try {
                        if (musica.getAnoLancamento() == Integer.parseInt(termo)) {
                            resultados.add(musica);
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Termo de busca para ano deve ser numérico");
                    }
                    break;
                default:
                    System.out.println("Critério inválido.");
                    return;
            }
        }
    
        if (resultados.isEmpty()) {
            System.out.println("Nenhuma música encontrada.");
        } else {
            System.out.println("Resultados da busca:");
            for (Musica musica : resultados) {
                musica.exibirInformacoes();
            }
        }
    }

    private static void reproduzirMusica(Scanner entrada, List<Musica> musicas) {
        if (musicas.isEmpty()) {
            System.out.println("Nenhuma música cadastrada para reproduzir.");
            return;
        }

        System.out.println("Músicas disponíveis:");
        for (int i = 0; i < musicas.size(); i++) {
            System.out.println(i + ". " + musicas.get(i).getTitulo() + " - " + musicas.get(i).getArtista().getNome());
        }
        System.out.print("Escolha a música para reproduzir: ");
        int escolhaMusica = -1;
        try {
            escolhaMusica = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaMusica < 0 || escolhaMusica >= musicas.size()) {
            System.out.println("Música inválida.");
            return;
        }

        Musica musicaSelecionada = musicas.get(escolhaMusica);
        musicaSelecionada.reproduzir();

        String comando;
        do {
            System.out.println("\n--- Controles de Reprodução ---");
            System.out.println("P - Pausar | R - Retomar | S - Parar | X - Sair dos Controles");
            System.out.print("Comando: ");
            comando = entrada.nextLine().toUpperCase();

            switch (comando) {
                case "P":
                    musicaSelecionada.pausar();
                    break;
                case "R":
                    musicaSelecionada.retomar();
                    break;
                case "S":
                    musicaSelecionada.parar();
                    break;
                case "X":
                    if (musicaSelecionada.estaEmReproducao() || musicaSelecionada.estaPausada()) {
                        musicaSelecionada.parar();
                    }
                    System.out.println("Saindo dos controles de reprodução de música.");
                    break;
                default:
                    System.out.println("Comando inválido.");
            }
        } while (!comando.equals("X"));
    }

    private static void reproduzirPlaylist(Scanner entrada, List<Playlist> playlists) {
        if (playlists.isEmpty()) {
            System.out.println("Nenhuma playlist criada para reproduzir.");
            return;
        }

        System.out.println("Playlists disponíveis:");
        for (int i = 0; i < playlists.size(); i++) {
            System.out.println(i + ". " + playlists.get(i).getNome());
        }
        System.out.print("Escolha a playlist para reproduzir: ");
        int escolhaPlaylist = -1;
        try {
            escolhaPlaylist = entrada.nextInt();
            entrada.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            entrada.nextLine();
            return;
        }

        if (escolhaPlaylist < 0 || escolhaPlaylist >= playlists.size()) {
            System.out.println("Playlist inválida.");
            return;
        }

        Playlist playlistSelecionada = playlists.get(escolhaPlaylist);

        if (playlistSelecionada.getMusicas().isEmpty()) {
            System.out.println("A playlist '" + playlistSelecionada.getNome() + "' está vazia. Não é possível reproduzir.");
            return;
        }

        playlistSelecionada.iniciarReproducao();

        String comando;
        do {
            System.out.println("\n--- Controles de Reprodução da Playlist ---");
            System.out.println("P - Pausar | R - Retomar | S - Parar | N - Próxima Música | A - Música Anterior | X - Sair dos Controles");
            System.out.print("Comando: ");
            comando = entrada.nextLine().toUpperCase();

            switch (comando) {
                case "P":
                    playlistSelecionada.pausarReproducao();
                    break;
                case "R":
                    playlistSelecionada.retomarReproducao();
                    break;
                case "S":
                    playlistSelecionada.pararReproducao();
                    break;
                case "N":
                    playlistSelecionada.proximaMusica();
                    break;
                case "A":
                    playlistSelecionada.musicaAnterior();
                    break;
                case "X":
                    if (playlistSelecionada.estaEmReproducaoPlaylist()) {
                        playlistSelecionada.pararReproducao();
                    }
                    System.out.println("Saindo dos controles de reprodução de playlist.");
                    break;
                default:
                    System.out.println("Comando inválido.");
            }
        } while (!comando.equals("X"));
    }

    private static void listarPlaylistsSalvas(List<Playlist> playlists) {
        if (playlists.isEmpty()) {
            System.out.println("Nenhuma playlist salva encontrada.");
            return;
        }
        System.out.println("\n--- Playlists Salvas ---");
        for (int i = 0; i < playlists.size(); i++) {
            Playlist p = playlists.get(i);
            System.out.println((i + 1) + ". " + p.getNome() + " (" + p.getMusicas().size() + " músicas)");
        }
    }
}