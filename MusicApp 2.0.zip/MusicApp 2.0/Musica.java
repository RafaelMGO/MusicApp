import java.io.Serializable;

public class Musica implements Serializable { 
    private static final long serialVersionUID = 1L;
    private String titulo;
    private Artista artista;
    private Album album;
    private String genero;
    private String duracao;
    private String formatoArquivo;
    private boolean emReproducao;
    private boolean pausada;

    public Musica(String titulo, Artista artista, Album album, String genero, String duracao, String formatoArquivo) {
        this.titulo = titulo;
        this.artista = artista;
        this.album = album;
        this.genero = genero;
        this.duracao = duracao;
        this.formatoArquivo = formatoArquivo;
        this.emReproducao = false;
        this.pausada = false;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAnoLancamento() {
        return album.getAnoLancamento();
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getFormatoArquivo() {
        return formatoArquivo;
    }

    public void setFormatoArquivo(String formatoArquivo) {
        this.formatoArquivo = formatoArquivo;
    }

    public boolean estaEmReproducao() {
        return emReproducao;
    }

    public boolean estaPausada() {
        return pausada;
    }

    public void reproduzir() {
        if (!emReproducao) {
            System.out.println("Reproduzindo música: " + titulo + " - " + artista.getNome());
            this.emReproducao = true;
            this.pausada = false;
        } else if (pausada) {
            System.out.println("Retomando reprodução de: " + titulo + " - " + artista.getNome());
            this.pausada = false;
        } else {
            System.out.println("Música '" + titulo + "' já está em reprodução.");
        }
    }

    public void pausar() {
        if (emReproducao && !pausada) {
            System.out.println("Música pausada: " + titulo);
            this.pausada = true;
        } else if (pausada) {
            System.out.println("Música '" + titulo + "' já está pausada.");
        } else {
            System.out.println("Música '" + titulo + "' não está em reprodução para ser pausada.");
        }
    }

    public void retomar() {
        if (emReproducao && pausada) {
            System.out.println("Retomando reprodução de: " + titulo);
            this.pausada = false;
        } else if (!emReproducao) {
            System.out.println("Música '" + titulo + "' não está em reprodução para ser retomada.");
        } else {
            System.out.println("Música '" + titulo + "' já está em reprodução, não está pausada.");
        }
    }

    public void parar() {
        if (emReproducao) {
            System.out.println("Parando reprodução de: " + titulo);
            this.emReproducao = false;
            this.pausada = false;
        } else {
            System.out.println("Música '" + titulo + "' não está em reprodução para ser parada.");
        }
    }

    public void exibirInformacoes() {
        System.out.println("Título: " + titulo);
        System.out.println("Artista: " + artista.getNome());
        System.out.println("Álbum: " + album.getNome());
        System.out.println("Gênero: " + genero);
        System.out.println("Ano de Lançamento: " + album.getAnoLancamento());
        System.out.println("Duração: " + duracao);
        System.out.println("Formato do Arquivo: " + formatoArquivo);
    }
}