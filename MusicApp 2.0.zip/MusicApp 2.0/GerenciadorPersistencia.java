import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GerenciadorPersistencia {
    private static final String NOME_ARQUIVO_PLAYLISTS = "playlists.dat";

 
    public static void salvarPlaylists(List<Playlist> playlists) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(NOME_ARQUIVO_PLAYLISTS))) {
            oos.writeObject(playlists);
            System.out.println("Playlists salvas com sucesso em " + NOME_ARQUIVO_PLAYLISTS);
        } catch (IOException e) {
            System.err.println("Erro ao salvar playlists: " + e.getMessage());
        }
    }

    public static List<Playlist> carregarPlaylists() {
        List<Playlist> playlists = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(NOME_ARQUIVO_PLAYLISTS))) {
            Object obj = ois.readObject();
            if (obj instanceof List) {
                playlists = (List<Playlist>) obj;
                System.out.println("Playlists carregadas com sucesso de " + NOME_ARQUIVO_PLAYLISTS);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo de playlists não encontrado. Iniciando com playlists vazias.");
        } catch (IOException e) {
            System.err.println("Erro de I/O ao carregar playlists: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.err.println("Erro de classe ao carregar playlists: " + e.getMessage());
            System.err.println("Pode ser que a estrutura das classes mudou desde a última gravação.");
        }
        return playlists;
    }
}