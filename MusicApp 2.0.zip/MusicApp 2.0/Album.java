import java.io.Serializable;

public class Album implements Serializable { 
    private static final long serialVersionUID = 1L; 
    private String nome;
    private Artista artista;
    private int anoLancamento;

    public Album(String nome, Artista artista, int anoLancamento) {
        this.nome = nome;
        this.artista = artista;
        this.anoLancamento = anoLancamento;
    }

    // Getters e setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }
}